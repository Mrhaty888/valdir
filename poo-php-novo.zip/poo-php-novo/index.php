<?php

require_once __DIR__.'/vendor/autoload.php.php';

use App\Mochila;
use App\Item;


$mochila = new Mochila();

$objeto1 = new Item("Espada",5);
$objeto2 = new Item("Poção",2);

$mochila->adicionarItens($objeto1);
$mochila->adicionarItens($objeto2);

$mochila->listarItens();
?>