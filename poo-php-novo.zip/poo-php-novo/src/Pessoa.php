<?php

namespace App;

class Pessoa{

   public function __construct( 
    public string $nome,
    public int $idade)
    {}

   public function apresentar(): string{
        return "Olá! seu nome é {$this->nome} e você tem {$this->idade} anos.".PHP_EOL;
   }
}

?>