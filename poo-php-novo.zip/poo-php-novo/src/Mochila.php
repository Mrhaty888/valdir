<?php

namespace App;

class Mochila{
    private array $itens = [];

    public function adicionarItens(Item $item): void{
        $this->itens[] = $item;
    }

    public function listarItens(): void{
        foreach($this->itens as $item){
            echo "Item: {$item->getNome()} | Peso: {$item->getPeso()}kg".PHP_EOL;
        }
    }
}
?>