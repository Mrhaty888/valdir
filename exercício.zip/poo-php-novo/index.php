<?php

require __DIR__.'/vendor/autoload.php';

use App\Produtos\Cafe;
use App\Contratos\Preparavel;

$cafe1 = new Cafe("Café", 14, 100);
?>