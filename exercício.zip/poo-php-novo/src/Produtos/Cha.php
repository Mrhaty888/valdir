<?php

namespace App\Produtos;
use App\Contratos;

class Cha extends Bebidas{
    private function aquecerAgua(): string{
        return "Aquecendo a água a 80° . . .".PHP_EOL;
    }
    private function prepararErva(): string{
        return "Preparando a erva . . .".PHP_EOL;
    }
    private function aguardando(): string{
        return "Tempo estimado de 3 minutos . . .".PHP_EOL;
    }
    private function FazerInfusao(): string{
        return "Fazendo infusão . . .".PHP_EOL;
    }
    private function coarServir(): string{
        return "Coando e servindo o chá . . .".PHP_EOL;
    }

    private function preparar(): string {
        echo $this->escaldarFiltro();
        echo $this->prepararErva();
        echo $this->aquecerAgua();
        echo $this->FazerInfusao();
        echo $this->extrair();
        return "Chá pronto".PHP_EOL;
    }
}
?>