<?php

namespace App\Produtos;

use App\Contratos;

class Sanduiche implements Preparavel{
    public function __construct(
        private string $nome,
        private float $preco,
        private float $Kg
    ) {
        if (trim($nome)=="") {
            throw new InvalidArgumentException('Nome inválido.');
        }
        if ($preco <= 0) {
            throw new InvalidArgumentException('Preço inválido.');
        }
        if ($Kg <= 0) {
            throw new InvalidArgumentException('Peso inválido.');
        }
    }

    protected function getNome(): string{
        return $this->nome;
    }
    protected function getPreco(): float{
        return $this->preco;
    }
    protected function getKg(): float{
        return $this->Kg;
    }

    private function pegarPresunto(): string{
        return "Pegando presunto . . .".PHP_EOL;
    }

    private function pegarQueijo(): string{
        return "Pegando queijo . . .".PHP_EOL;
    }

    private function Grelhando(): string{
        return "Grelhando . . .".PHP_EOL;
    }

    public function Preparavel(): string{
       echo $this->pegarPresunto();
       echo $this->pegarQueijo();
       echo $this->Grelhando();
       return "Sanduiche pronto!".PHP_EOL;
    }
}
?>