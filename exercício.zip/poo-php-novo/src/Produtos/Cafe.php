<?php

namespace App\Produtos;
use App\Contratos;
use InvalidArgumentException;

class Cafe extends Bebidas{

    private function aquecerAgua(): string{
        return "Aquecendo a água a 92° . . .".PHP_EOL;
    }
    private function prepararPo(): string{
        return "Preparando o pó . . .".PHP_EOL;
    }
    private function escaldarFiltro(): string{
        return "Escaldando de filtro . . .".PHP_EOL;
    }
    private function FazerPreInfusao(): string{
        echo "Fazendo pré-infusão . . .";
        return "Esperando 30 segundos . . .".PHP_EOL;
    }
    private function extrair(): string{
        return "Extraindo o  café . . .".PHP_EOL;
    }

    private function preparar(): string {
        echo $this->escaldarFiltro();
        echo $this->prepararPo();
        echo $this->aquecerAgua();
        echo $this->FazerPreInfusao();
        echo $this->extrair();
        return "Café pronto".PHP_EOL;
    }

    public function executarPreparo(): string{
        return $this->Preparar();
    }
}
?>