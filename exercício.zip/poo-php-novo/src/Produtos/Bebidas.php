<?php

namespace App\Produtos;
use App\Contratos;

use InvalidArgumentException;

abstract class Bebidas implements Preparavel{
    public function __construct(
        private string $nome,
        private float $preco,
        private float $volume,
    ){
        if (trim($nome)=="") {
            throw new InvalidArgumentException('Nome inválido.');
        }
        if ($preco <= 0) {
            throw new InvalidArgumentException('Preço inválido.');
        }
        if ($volume <= 0) {
            throw new InvalidArgumentException('Volume inválido.');
        }
    }

    public function getNome(): string{
        return $this->nome;
    }
    public function getPreco(): float{
        return $this->preco;
    }
    protected function getVolume(): float{
        return $this->volume;
    }

    abstract protected function executarPreparo(): string;

}
?>