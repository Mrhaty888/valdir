<?php

namespace App\Contratos;

interface Preparavel {
    public function preparar(): string;
}
?>