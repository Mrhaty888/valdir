<?php
namespace App;

class Pedido{
    private array $produtos = [];

    public function __construct(string $nome){
        if (trim($nome)=="") {
            throw new InvalidArgumentException('Nome inválido.');
        }
    }

    public function adicionarProduto() {
        
    }
}
?>