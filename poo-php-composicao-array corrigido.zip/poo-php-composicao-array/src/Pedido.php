<?php

namespace App;

class Pedido
{
    private array $itens = []; # [] declara um novo array vazio no PHP

    public function adicionarItem(ItemPedido $item): void 
    {   
        $tem = 0;
        foreach ($this->itens as $item_lista){
            if ($item_lista->getProduto() == $item->getProduto()) {
                $tem = 1;
                break;
            } else {
                $tem = 0;
            }
        }
        if ($tem != 1) {
            $this->itens[] = $item; 
        } else {
            echo "Item já cadastrado".PHP_EOL;# nesse formato se adiciona um item ao final da lista
        }
    }

    public function removerItem(ItemPedido $item): void{
        for ($i=0; $i<count($this->itens); $i++) {
            if ($this->itens[$i]->getProduto() == $item->getProduto()) {
                unset($this->itens[$i]);
                echo "Item removido".PHP_EOL;
                break;
            }
        }
    }
    public function calcularTotal(): float
    {
        $total = 0;
        foreach($this->itens as $item) {
            $total += $item->calcularSubTotal();
        }

        return $total;
    }

    public function listarItens(): void
    {
        echo "Itens no pedido: " . PHP_EOL;
        foreach($this->itens as $item) {
            echo "- {$item->getProduto()} | Sub total: R$ {$item->calcularSubTotal()}" . PHP_EOL;
        }
    }
}