# Implementação — README de execução local

- Papel: Coder.
- Estado: READY para validação independente do QA; não constitui aprovação.
- Tarefa: TASK-001, vinculada a REQ-001–REQ-005 e AC-001–AC-005.
- Arquivos de propriedade: `README.md` e este `implementation.md`.

## Entrega e decisões

Criado README em português com objetivo didático, requisito PHP `^8.4` explicado como >=8.4 e <9.0, Composer 2, preparação Windows/macOS/Linux, verificação dos executáveis, obtenção por ZIP fornecido pelo professor, navegação até a pasta correta, geração de autoload, execução e saída real. Incluídos estrutura, edição/reexecução, diagnóstico de erros e navegador opcional com servidor em loopback e Ctrl+C.

Não foi inventada URL de clone. Para Linux, os comandos APT estão limitados explicitamente ao Ubuntu e derivados, com exigência de conferir a versão e orientação quando o repositório padrão não oferecer PHP compatível. A instalação do Composer remete à verificação atual do instalador oficial e explica instalação por usuário. A aplicação, os manifests, o lockfile e `vendor/` não foram alterados.

## Evidências executadas

Ambiente macOS; comandos na raiz do projeto:

| Comando | Resultado real |
| --- | --- |
| `php -v` | Código 0, PHP 8.5.5 CLI, Homebrew. |
| `composer --version` | Código 0, Composer 2.9.7, PHP 8.5.5. |
| `php index.php` | Código 0; saída reproduzida abaixo. |
| `composer check-platform-reqs` | Código 0; `php 8.5.5 success`. Aviso de versão raiz assumida `1.0.0`; verificação reportou uso do lockfile. |
| `php -l index.php` | Código 0, sem erros de sintaxe. |
| `php -l src/ItemPedido.php` | Código 0, sem erros de sintaxe. |
| `php -l src/Pedido.php` | Código 0, sem erros de sintaxe. |
| `git diff --check -- README.md docs/features/readme-local/implementation.md` | Código 0, sem saída; limite: arquivos novos não rastreados não são cobertos por esse comando. |

Saída do exemplo (há um espaço final após o título no programa):

```text
Itens no pedido:
- Teclado | Sub total: R$ 543.78
- Mouse | Sub total: R$ 387.34
Total: R$ 931,12
```

## Fontes conferidas em 08/10/2026

- [PHP Windows: instalação manual e requisitos](https://www.php.net/manual/en/install.windows.manual.php).
- [PHP Windows: linha de comando e PATH](https://www.php.net/install.windows.commandline.php).
- [PHP macOS: Homebrew](https://www.php.net/manual/en/install.macosx.packages.php).
- [Homebrew: fórmula PHP](https://formulae.brew.sh/formula/php) e [fórmula Composer](https://formulae.brew.sh/formula/composer).
- [Ubuntu: PHP CLI](https://ubuntu.com/server/docs/programming-php/) — instrução `sudo apt install php-cli` encontrada via busca oficial; o primeiro acesso à rota nova da documentação expirou.
- [Composer: instalação por sistema](https://getcomposer.org/doc/00-intro.md) e [download](https://getcomposer.org/download/).
- [PHP: servidor embutido](https://www.php.net/manual/en/features.commandline.webserver.php).

## Limitações e handoff

Não foram executadas instalações completas de ferramentas em Windows/Linux/macOS, configuração de PATH, download de ZIP ou acesso pelo navegador. Não foram criados testes de aplicação para uma alteração documental. A preparação sem `vendor/`, com `composer install`, fica para TASK-002 do QA em cópia descartável, conforme plano. Os comandos de instalação de ferramentas estão fundamentados nas fontes indicadas, não em instalação nesta máquina.

Próximo destinatário: principal → QA, para validar independentemente o README atual e AC-001–AC-005, incluindo preparação limpa e comparação de saída. Sem bloqueios de implementação.
