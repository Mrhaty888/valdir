# Tarefas: README de execução local

## TASK-001 — Criar guia do aluno

- Estado: READY.
- Responsável: Coder.
- Dependência: plano técnico concluído; pedido do usuário autoriza criação do README.
- Requisitos: REQ-001 a REQ-005; critérios AC-001 a AC-005.
- Propriedade: `README.md` na raiz e `docs/features/readme-local/implementation.md`.
- Entrega: passo a passo claro em português, desde instalação/verificação dos programas e obtenção do código até `composer install`, `php index.php`, saída esperada, estrutura e problemas comuns.
- Restrições: não alterar aplicação, `composer.json`, `composer.lock` ou arquivos alheios; não inventar URL Git; não sugerir `--ignore-platform-reqs` ou `composer update` como preparação normal.
- Evidência: registrar comandos efetivamente executados e saída; conferir fontes oficiais para orientação de instalação quando necessário e registrar limitações de sistemas não testados.
- Conclusão: arquivo legível para iniciante, todos os ACs cobertos e handoff ao QA com resumo e arquivos alterados.

## TASK-002 — Validar guia independentemente

- Estado: READY após TASK-001.
- Responsável: QA.
- Propriedade: `docs/features/readme-local/qa-report.md`.
- Validação: conferir AC-001 a AC-005 contra código e manifesto; reproduzir preparação em cópia descartável sem `vendor/`, executar `composer install` e `php index.php` e comparar com a saída documentada.
- Conclusão: APPROVED para o conteúdo atual, ou CHANGES_REQUIRED com BUG estável e evidência reproduzível. Registrar comandos reais, arquivos/diff validados e plataformas não testadas.
- Próximo responsável: principal em caso de aprovação; Tech Lead se houver correções.
