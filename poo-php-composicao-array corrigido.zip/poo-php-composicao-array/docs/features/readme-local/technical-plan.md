# Plano técnico: README de execução local

## Escopo e evidências

Documentar o projeto didático PHP existente, sem alterar aplicação, manifesto ou lockfile. Não há PRD, design ou AGENTS.md local; o pedido do usuário é suficiente para esta mudança documental. O workflow foi consultado.

- `composer.json` exige PHP `^8.4` (8.4 ou superior dentro da série 8.x) e define autoload PSR-4 de `App\` para `src/`.
- `composer.lock` não possui pacotes externos; Composer ainda é necessário para gerar `vendor/autoload.php`, carregado por `index.php`.
- `src/ItemPedido.php` calcula subtotais; `src/Pedido.php` agrega itens em array e calcula o total.
- Não há banco de dados, `.env`, Node, framework ou serviço externo exigido pelo código.
- Execução real em PHP 8.5.5 e Composer 2.9.7: `php index.php` terminou com código 0 e total `R$ 931,12`.

## Requisitos e critérios

- REQ-001 / AC-001: README em português, explicando objetivo, pré-requisitos PHP 8.4–8.x e Composer, instalação inicial para Windows/macOS/Linux e verificação com `php -v` e `composer --version`.
- REQ-002 / AC-002: orientar a obter/extrair o projeto e abrir terminal na pasta que contém `composer.json` e `index.php`; não inventar URL Git.
- REQ-003 / AC-003: explicar `composer install`, geração do autoload e execução `php index.php`, com saída esperada real.
- REQ-004 / AC-004: oferecer diagnóstico para comandos ausentes/PATH, versão incompatível, pasta errada, autoload ausente e classe não encontrada, sem ignorar requisitos de plataforma.
- REQ-005 / AC-005: apresentar estrutura essencial e fluxo de edição/reexecução; eventual navegador é opcional e deve explicar servidor local, URL e Ctrl+C, além das quebras de linha em texto puro.

## Decisões e contratos

O terminal é o fluxo principal porque a saída usa `PHP_EOL`. Não será exigido Apache/XAMPP; se citado como opção, verificar PHP real no terminal. Instalação dos programas deve apontar para fontes oficiais; comandos de gerenciadores só se acompanhados de pré-requisitos e confirmados. Como a URL do repositório não está disponível, descrever download fornecido pelo professor/ZIP e usar caminhos ilustrativos claramente identificados.

README é o único artefato voltado ao aluno. Coder possui `README.md` e `implementation.md`; Tech Lead possui este plano e `tasks.md`; QA possui `qa-report.md`. Não modificar arquivos PHP ou executar atualizações de dependências. A restrição relativa a Composer de entregas não confiáveis do avaliador não se aplica: este repositório é o próprio projeto didático solicitado.

## Validação

Coder verifica coerência de comandos e saída, registra execução real e limitações. QA lê README e fontes independentemente, verifica os ACs e executa uma cópia descartável sem `vendor/`, com `composer install` e `php index.php`, para demonstrar que o aluno não depende do autoload já presente. `composer check-platform-reqs` pode confirmar compatibilidade. Não é necessário criar testes automatizados para esta documentação. Instalação completa em Windows/Linux não deve ser alegada sem execução nesses sistemas.
