# QA — README de execução local

- Papel: QA; status **APPROVED**; rodada 1; data 08/10/2026.
- Tarefa: TASK-002; cobertura REQ-001–REQ-005 / AC-001–AC-005.
- Resumo: o guia permite preparar o autoload e executar o projeto didático, explica os pré-requisitos reais e oferece diagnóstico adequado ao iniciante. Nenhum BUG identificado.
- Propriedade: somente este relatório. Aplicação, README e documentos de aceite não foram alterados pelo QA.

## Entradas e versão validada

Lidos `technical-plan.md`, `tasks.md`, `implementation.md`, `workflow.md`, README completo, `composer.json`, `composer.lock`, `index.php`, `src/ItemPedido.php` e `src/Pedido.php`. Não há PRD separado para esta mudança documental; requisitos e critérios estão no plano técnico.

README validado: SHA-256 `bdcb5978ef09c520779f8b1564c2e83a4427beadeabe09aa7344c1c9ef49fe9d`.

`git status --short -- .` retornou `?? ./`: este projeto está não rastreado no repositório ancestral. `git diff -- README.md` ficou vazio e não representa a criação do arquivo; por isso a identificação da versão usa o hash do conteúdo integral. A revisão considerou o README novo inteiro, sem alegar comparação histórica da aplicação.

## Matriz de aceite

| AC | Cenário | Evidência | Resultado |
| --- | --- | --- | --- |
| AC-001 | Aluno identifica objetivo, instala e verifica programas | README em português; Windows com ZIP NTS, PATH e Composer Setup; macOS com Homebrew; Linux com APT limitado a Ubuntu e verificação explícita de compatibilidade. `^8.4` corresponde a >=8.4 e <9.0, confirmado no manifesto e na documentação do Composer. | PASS |
| AC-002 | Aluno obtém projeto e abre a pasta correta | Download/extração por material do professor; exemplos claramente ilustrativos; `cd`, `dir`/`ls` e identificação conjunta de manifesto e index. Nenhuma URL Git inventada. | PASS |
| AC-003 | Instalação limpa gera autoload e executa | Cópia sem vendor; `composer install` código 0; duas execuções de `php index.php` código 0, total `R$ 931,12`, saída igual à documentada após desconsiderar espaço visual final no título. | PASS |
| AC-004 | Diagnóstico de falhas comuns | PATH, versão, pasta, autoload e classe ausente descritos. Pasta errada reproduziu falha; autoload ausente reproduziu erro citado. Não há orientação para ignorar requisitos. | PASS |
| AC-005 | Aluno entende estrutura, edita e reexecuta | Estrutura corresponde aos arquivos; explicação de salvar/reexecutar e ponto decimal; navegador opcional em loopback com URL, Ctrl+C, porta alternativa e aviso sobre quebras de linha. | PASS |

## Preparação e comandos reais

Ambiente: macOS, PHP 8.5.5 CLI (Homebrew), Composer 2.9.7. Um script Python com `tempfile.mkdtemp`, `shutil.copy2` e `shutil.copytree` copiou somente README, manifests, index e src para `/private/tmp/readme-qa-m2imfaqc`. Confirmado `vendor inicialmente existe: False`. A aplicação executada é o projeto de aula explicitamente solicitado, não uma submissão de aluno não confiável.

| Comando ou verificação | Resultado real |
| --- | --- |
| `php -v` | Código 0; PHP 8.5.5 CLI. |
| `composer --version` | Código 0; Composer 2.9.7. |
| `composer install` na cópia | Código 0; lockfile validado; `Nothing to install, update or remove`; `Generating autoload files`; aviso benigno da versão raiz `1.0.0`. |
| `php index.php`, duas vezes na cópia | Ambos código 0, stderr vazio; stdout idêntico byte a byte entre execuções. |
| Comparação Python da saída com bloco esperado do README | PASS; removidos apenas espaços finais das linhas para comparação visual. |
| `composer check-platform-reqs` na cópia | Código 0; `php 8.5.5 success`; Composer informou verificação pelo lockfile e repetiu aviso da versão raiz. |
| `php -l index.php` | Código 0; sem erro de sintaxe. |
| `php -l src/ItemPedido.php` | Código 0; sem erro de sintaxe. |
| `php -l src/Pedido.php` | Código 0; sem erro de sintaxe. |
| `php index.php` em subpasta vazia da cópia | Código 1; `Could not open input file: index.php`. |
| `composer install` em subpasta vazia da cópia | Código 1; não encontrou `composer.json`. |
| `php index.php` após renomear temporariamente vendor na cópia | Código 255; falha em `vendor/autoload.php`, conforme diagnóstico do README. A pasta foi restaurada. |
| Comparação binária por Python de README, manifests e três arquivos PHP entre original e cópia ao fim | Todos iguais; preparação não modificou o original nem o lockfile copiado. |

Saída real, incluindo espaço após os dois-pontos do título (invisível no bloco):

```text
Itens no pedido:
- Teclado | Sub total: R$ 543.78
- Mouse | Sub total: R$ 387.34
Total: R$ 931,12
```

Os subprocessos do script QA utilizaram listas de argumentos, `capture_output=True` e timeout de 10 ou 15 segundos, sem `shell=True`. Nenhum script desse tipo foi incorporado ao produto.

## Fontes oficiais conferidas

- [Composer: restrições de versão](https://getcomposer.org/doc/articles/versions.md), incluindo operador caret.
- [Composer: instalação](https://getcomposer.org/doc/00-intro.md), incluindo instalador Windows e instalação por usuário em `.local/bin`.
- [PHP: instalação Windows](https://www.php.net/manual/en/install.windows.manual.php), para NTS em CLI e requisito Visual C++.
- [PHP: instalação macOS](https://www.php.net/manual/en/install.macosx.packages.php), [fórmula PHP](https://formulae.brew.sh/formula/php) e [fórmula Composer](https://formulae.brew.sh/formula/composer), para comandos Homebrew.
- [Ubuntu: PHP](https://ubuntu.com/server/docs/programming-php/), comando PHP CLI confirmado pelo resultado da busca oficial; a abertura direta retornou conteúdo sem instruções utilizáveis.
- [PHP: servidor embutido](https://www.php.net/manual/en/features.commandline.webserver.php), para servidor de desenvolvimento.

## Limitações e checks não executados

Não foram realizadas instalações completas de PHP/Composer, alteração de PATH, download/extração de ZIP ou execução em Windows/Linux. As instruções desses sistemas foram verificadas documentalmente; o fluxo real foi reproduzido em macOS. Não foram testados navegador, porta ocupada, edição de valores nem nomes de classe incorretos; seus passos foram conferidos contra o código e fontes.

Tree-sitter/AST e cenários ZIP traversal/symlink/limites, Docker sem rede e execução de submissões não foram executados: este repositório é o exemplo PHP de aula, sem parser, avaliador, extração programática de ZIP, subprocessos de produto ou Docker, e a mudança é exclusivamente documental. O uso de Composer aqui prepara o próprio exemplo autorizado, não executa uma entrega não confiável. Inspeção integral dos três arquivos PHP e manifests não encontrou IA, LLM, API externa, dependência OpenAI ou transmissão de dados no runtime. O lockfile não contém pacotes externos. Não foram criadas fixtures ou testes de produção para esta documentação.

## Handoff

APPROVED se aplica ao hash de README acima e aos cinco AC obrigatórios. Sem pendências corretivas; próximo destinatário: agente principal, para atualizar o workflow e entregar o README ao usuário. Uma alteração posterior do README requer revalidação pertinente.
