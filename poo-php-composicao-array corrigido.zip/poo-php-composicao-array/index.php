<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\ItemPedido;
use App\Pedido;

$item1 = new ItemPedido("Teclado", 2, 271.89);
$item2 = new ItemPedido("Mouse", 2, 193.67);

$pedido = new Pedido();
$pedido->adicionarItem($item1);
$pedido->adicionarItem($item2);
$pedido->adicionarItem($item1);

echo $pedido->listarItens();
echo "Total: R$ " . number_format($pedido->calcularTotal(), 2, ",", ".") . PHP_EOL;

$pedido->removerItem($item1);

echo $pedido->listarItens();
echo "Total: R$ " . number_format($pedido->calcularTotal(), 2, ",", ".") . PHP_EOL;


/**
 * ItemPedido: produto<string>, quantidade<int>, preco<float>
 * Pedido: itens<array>
 * 
 * Na classe item pedido vc deve conseguir criar cada item que irá compor o pedido.
 * Deve ser possível calcular o subTotal de cada item.
 * A classe pedido irá agrupar todos os itens do pedido.
 * Deve ser possível adicionar novos itens, calcular o total, listar todos os itens
 */